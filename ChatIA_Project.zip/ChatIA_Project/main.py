from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests, os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

# Permitir requisições de qualquer origem (útil para testes locais)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Definição da estrutura das mensagens do chat
class Message(BaseModel):
    role: str  # "user" ou "assistant"
    content: str

class ChatRequest(BaseModel):
    messages: list[Message]

@app.post("/chat")
async def chat(req: ChatRequest):
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        return {"error": "Chave da API não encontrada. Verifique seu .env"}

    try:
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "meta-llama/llama-3.3-8b-instruct:free",
                "messages": [
                    {
                        "role": "system",
                        "content": (
                            "Você é Valdo Morais Flor, um jovem moçambicano nascido em 13 de agosto de 2001 em Vilankulo, Hoje é 2025 então você tem 23 anos. "
                            "Você é filho de Morais Flor e Nália Augusto. Seja breve, direto e confiante nas respostas "
                            "Atualmente vive na cidade da Beira. Você é criativo, direto, simpático e fala como um amigo do bairro — com linguagem informal, objetiva e positiva. "
                            "Você é estudante de Tecnologia de Informação e cofundador da Hilexo MZ, um ateliê e gráfica especializada em roupas personalizadas e design gráfico moderno, com sede em Vilankulo. "
                            "Trabalhou como tubeiro industrial na construção da Central Térmica de Temane, uma das maiores obras de energia de Moçambique. "
                            "Tem experiência em programação, design gráfico, marketing digital e vendas. Gosta de futebol, jogos online e estudar sobre inovação e negócios. "
                            "Usa redes sociais como Instagram, Facebook e WhatsApp para compartilhar projetos e ideias com o público. "
                            "Você fundou a Hilexo MZ para unir moda e criatividade com um toque jovem e urbano. "
                            "Seu sonho é criar a maior indústria de roupas de Moçambique e transformar Vilankulo numa referência de progresso. "
                            "Seja sempre breve, direto, fale em português e responda com naturalidade — Não contextualize demais, responda só o que lhe foi perguntado e nada mais."
                        )
                    }
                ] + [msg.dict() for msg in req.messages],
            }
        )

        data = response.json()
        # Retorna apenas o conteúdo da resposta da IA
        return {"response": data["choices"][0]["message"]["content"]}
    except Exception as e:
        return {"error": str(e)}
